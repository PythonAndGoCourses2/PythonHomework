#!/usr/bin/env python3

"""Pure-python command-line calculator - package."""


name = "pycalc"
